<?php $__env->startSection('extraFrontEndCSS'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('back_end_main_contents'); ?>
	<button class="btn btn-success" data-toggle="modal" data-target="#sign_up_modal">Sign-up</button>

	<?php echo $__env->make('pages.front_end.modals.sign_up', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extraFrontEndJS'); ?>
	<script>
	    jQuery(document).ready(function($) {
	        const app = new Vue({
	            el: '#app',
	            data: {

	            },
	            mounted() {

	            },
	            methods: {

	            }
	        });
	    });
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front_end_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>