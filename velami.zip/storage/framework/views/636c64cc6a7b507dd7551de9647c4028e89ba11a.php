<?php $__env->startSection('extraCSS'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
Welcome to Dashboard!
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>