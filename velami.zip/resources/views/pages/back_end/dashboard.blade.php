@extends('layouts.app')

@section('extraCSS')

@endsection

@section('content')
    Welcome to Dashboard!
@endsection
