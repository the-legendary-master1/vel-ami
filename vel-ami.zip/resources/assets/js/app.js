require('./bootstrap');

window.Vue = require('vue');

import dropify from 'dropify';
import swal from 'sweetalert';

// Vue.component('example-component', require('./components/ExampleComponent.vue'));

// const app = new Vue({
//     el: '#app'
// });
