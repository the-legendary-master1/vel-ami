
@extends('layouts.frontend_layout')

@section('content')
<h1>MY SHOP!</h1>
@endsection

