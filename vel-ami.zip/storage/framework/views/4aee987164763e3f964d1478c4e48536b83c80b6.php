<?php $__env->startSection('extraCSS'); ?>
	<style>
		.shops-items{
			width: 100%;
			background-color: #f5f5f5;
			padding: 10px 20px;
			border: solid 1px #cccccc;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
    	<div class="col-sm-3" v-for="item in allShops">
    		<div class="card shops-items">
	        	<img :src="'<?php echo e(asset('files')); ?>/'+item.shop_img" class="img-responsive" alt="" v-if="item.shop_img">
    			<img src="<?php echo e(asset('files/shop.png')); ?>" class="img-responsive" alt="" v-else>
    		</div>
    	</div>
    </div>
<?php $__env->stopSection(); ?>
	
<?php $__env->startSection('extraJS'); ?>
    <script>
        $(document).ready(function() {	
            const app = new Vue({
                el: '#app',
                data: {
                	allShops: <?php echo json_encode($shops); ?>

                }, 
                mounted() {
                    Echo.channel('get-shops')
                        .listen('.get-shops', () => {
                            this.getShops();
                        })
                },
                methods: {
	                getShops() {
	                	axios.get('<?php echo e(url('super-admin/get-shops')); ?>')
	                		.then((response) => {
	                			this.allShops = response.data;
	                		})
	                },
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>