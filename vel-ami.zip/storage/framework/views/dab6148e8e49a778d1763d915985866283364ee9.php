<?php $__env->startSection('content'); ?>
    <div class="content-title text-left">
        <div class="mr-auto text-left">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb clearfix d-none d-md-inline-flex pt-0">
                    <li class="breadcrumb-item active">Home</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="main-content mt2">
        <div class="content-title text-center pb2">
            <h2 class="page-title">Featured Products</h2>
            <div class="line"></div>
            <h6 class="strapline">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua </h6>
        </div>
        <div class="products mt2">
            <div class="row text-center">
                <?php if( count($products) > 0 ): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 pi cus-pad">
                            <div class="product--details">
                                <a href="<?php echo e(url('/product')); ?>/<?php echo e(preg_replace('/\s+/', '_', $product->name)); ?>/<?php echo e(base64_encode($product->id)); ?>" class="item-link">
                                    <div class="text-center item--product item--hover">
                                        <div class="item-img mb-3">

                                            <?php $__currentLoopData = json_decode($product->images, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($index == 0): ?>
                                                    <img src="<?php echo e(url('/')); ?>/<?php echo e($image['path']); ?>" alt="<?php echo e($product->name); ?>" class="img-responsive"> 
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           
                                        </div>
                                        <div class="item-details">
                                            <h6 class="shop-name text-uppercase mb1 font-weight-bold show-desktop"><?php echo e($product->shop['name']); ?></h6>
                                            <h5 class="item-name mb2 font-weight-bold"><?php echo e($product->name); ?></h5>

                                            <div class="prRa clearfix">
                                                <span class="price">₱ <?php echo e($product->price); ?></span>
                                                <div class="pull-right show-mobile">
                                                    <span class="fa fa-star fa-1x text-info"></span>
                                                    <span class="fa fa-star fa-1x text-info"></span>
                                                    <span class="fa fa-star fa-1x text-info"></span>
                                                    <span class="fa fa-star fa-1x text-info"></span>
                                                    <span class="fa fa-star fa-1x text-info"></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <h1><i>No products available...</i></h1>
                <?php endif; ?>
                    
            </div>
            <div class="row">
                <div class="pagination-container text-center">
                    <nav aria-label="paginate products">
                        <ul class="pagination justify-content-center">
                            <li class="page-item disabled">
                                <a class="page-link" href="#" tabindex="-1">Previous</a>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('extraJS'); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.frontend_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>